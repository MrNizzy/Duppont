/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package duppont;

//import java.awt.Graphics;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import javax.swing.JFrame;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.JLabel;

/**
 *
 * @author Nizzy
 */
public class Tablero extends JFrame implements Atributos{
    
    JLabel Duppont = new JLabel("Duppont");
    
                    //Constructor
    public Tablero(){
        setBackground(Color.black);
        setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
        setVisible(true);
        //setBackground(Color.yellow);
        setLocation(300, 100);
        setResizable(false);
        
        setTitle("Duppont v1.1");
        setDefaultCloseOperation(EXIT_ON_CLOSE);    
        add(Duppont);
    }
    @Override
    public void paint(Graphics g){
        //Fondo
        g.setColor(Color.decode("#00688b"));
        g.fillRect(0, 0, WINDOW_WIDTH, WINDOW_HEIGHT);
        //PanelGame
        g.setColor(Color.decode("#add8e6"));
        g.fillRect(20, 80, (WINDOW_WIDTH-200), (WINDOW_HEIGHT-100));
        //PanelMenu
        g.setColor(Color.decode("#add8e6"));
        g.fillRect(WINDOW_WIDTH-160, 80, 136, 386);
        
        g.setFont(new Font("Arial", Font.BOLD, 20));
        g.setColor(Color.yellow);
        g.drawString("Duppont", 10, 20);
        
        
        
    }
    
    
    
}
