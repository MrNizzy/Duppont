/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package duppont;

/**
 *
 * @author Nizzy
 */
public interface Atributos {

    //Window
    public static final int WINDOW_WIDTH = 784;
    public static final int WINDOW_HEIGHT = 486;
    
    //Panel Juego
    public static final int PANELGAME_WIDTH = 700;
    public static final int PANELGAME_HEIGHT = 400;
}
