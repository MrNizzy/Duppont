/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Game;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JFrame;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author Nizzy
 */
public class Tablero extends JFrame{
    public JPanel Menu = new JPanel();
    public JPanel Tablero = new JPanel();
    public Tablero(){
        setSize(784, 486);
        setVisible(true);
        //setBackground(Color.black);
        setBackground(Color.yellow);
        setLocation(300, 100);
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        //JPanel Tablero = new JPanel();
        //Tablero.setLayout(null);
        //Tablero.setPreferredSize(new Dimension(784,486));
        Tablero.setBackground(Color.decode("#6895fa"));
        Tablero.setVisible(true);
        
        
        JLabel Title = new JLabel("Duppont");
        Title.setVisible(true);
        //Title.setIcon(new ImageIcon("title.png"));
        //Title.setLayout(null);
        //Title.setPreferredSize(new Dimension(20,50));
        Title.setFont(new Font("Arial", Font.BOLD, 30));
        Title.setForeground(Color.decode("#1c528d"));
        
        JPanel PanelGame = new JPanel();
        //PanelGame.setLayout(null);
        PanelGame.setPreferredSize(new Dimension(700,400));
        PanelGame.setLocation(20, 20);
        PanelGame.setBackground(Color.decode("#e6e6fa"));
        PanelGame.setLocation(20, 20);
        PanelGame.setVisible(true);
        //Menu.setLayout(null);
        /*Menu.setPreferredSize(new Dimension(40, 400));
        Menu.setBackground(Color.decode("#e6e6fa"));
        Menu.setVisible(true);*/
        
        
        Tablero.add(Title);
        Tablero.add(PanelGame);
        //Tablero.setLayout(null);
    }
    
    public void GetLabel(){                
        Menu.setPreferredSize(new Dimension(40, 400));
        Menu.setBackground(Color.decode("#e6e6fa"));
        Menu.setVisible(true);
        Tablero.add(Menu);
        
        //JButton prueba = new JButton();
        add(Tablero);
    }
    
    @Override
    public void paint(Graphics g){
        g.fillRect(100, 200, 150, 150);
    }
    
}
