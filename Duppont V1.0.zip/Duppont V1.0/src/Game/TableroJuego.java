/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Game;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JPanel;

/**
 *
 * @author HOME
 */
public class TableroJuego extends JPanel {
    Pelota pelota;
    paletas p1;
    
  
    public TableroJuego() {
        setBackground(Color.BLACK);
       p1 = new paletas(300,300);
       pelota= new Pelota(0, 0);
       setLayout(null);
       add(p1); 
    }
    public void posicion(){
       
         // System.out.println(pelota.getx());
       //System.out.println(pelota.gety());
       /*  if((pelota.gety()==p1.getY())&(pelota.getx()==p1.getX())){
             System.out.println("hola");  
         } */
   
         if((pelota.getx()>=p1.getX())&  //b->balon  p->pelota
		    (pelota.getx()<=p1.getX()+p1.getAncho())&
		    (pelota.gety()+p1.getAlto()>=p1.getY())){
             
          pelota.reflejar();  
         }
             }
         
    
    
    @Override
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D)g;
        g2.setColor(Color.WHITE);
        dibujar(g2);
        actualizar();
        posicion();
    }
    
    public void dibujar(Graphics2D g){
        g.fill(pelota.getPelota());
      
    }
    
    public void actualizar(){
        pelota.mover(getBounds());
    }

}
