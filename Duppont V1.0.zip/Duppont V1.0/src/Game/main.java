/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Game;

import java.awt.Color;

/**
 *
 * @author Nizzy
 */
public class main{

    
    
    
    public static void main(String[] args){
        Tablero Ventana = new Tablero();
        TableroJuego asd = new TableroJuego();
        Ventana.GetLabel();
        Ventana.repaint();
    }
    
    
}
